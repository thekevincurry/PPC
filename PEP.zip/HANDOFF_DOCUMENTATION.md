# PEP Automation — Complete Handoff Documentation

> **Last Updated:** March 2026  
> **Audience:** Incoming team taking ownership of this project  
> **Runtime:** Windows only (requires Excel COM / `win32com`)

---

## Table of Contents

1. [Project Overview](#1-project-overview)
2. [Business Context](#2-business-context)
3. [Architecture & Data Flow](#3-architecture--data-flow)
4. [Prerequisites & Environment Setup](#4-prerequisites--environment-setup)
5. [Directory Structure](#5-directory-structure)
6. [Configuration Reference](#6-configuration-reference)
7. [How to Run](#7-how-to-run)
8. [Detailed Processing Pipeline](#8-detailed-processing-pipeline)
9. [Database & Data Sources](#9-database--data-sources)
10. [Caching System](#10-caching-system)
11. [Parallel Processing](#11-parallel-processing)
12. [Retry, Resume & Checkpointing](#12-retry-resume--checkpointing)
13. [Output & Delivery](#13-output--delivery)
14. [Excel Template Workbooks](#14-excel-template-workbooks)
15. [Key Functions Reference](#15-key-functions-reference)
16. [Error Handling & Recovery](#16-error-handling--recovery)
17. [Logging & Diagnostics](#17-logging--diagnostics)
18. [Performance Optimizations](#18-performance-optimizations)
19. [Troubleshooting Guide](#19-troubleshooting-guide)
20. [Maintenance & Year-over-Year Changes](#20-maintenance--year-over-year-changes)
21. [Known Limitations & Risks](#21-known-limitations--risks)
22. [Glossary](#22-glossary)

---

## 1. Project Overview

**PEP Automation** is a Python-based automation tool that generates individualized provider-group Excel workbooks (`.xlsb`) for the **Pharmacy Engagement Program (PEP)**. It pulls pharmacy adherence and provider collaboration data from a SQL Server database, filters it per provider group, populates a template Excel workbook via COM automation, and delivers the completed files to a shared drive.

### What it does in one sentence

> Reads a "Report Workbook" listing all provider groups, fetches STAR medication-adherence data from SQL Server, and mass-produces one customized `.xlsb` dashboard workbook per provider group — with parallel processing, caching, retry logic, and checkpoint/resume support.

---

## 2. Business Context

| Concept | Detail |
|---------|--------|
| **Program** | Pharmacy Engagement Program (PEP) |
| **Domain** | CMS STAR Ratings — Medication Adherence (Part D) |
| **Measures** | ACE/ARB (Hypertension), Diabetes medications, Statins (Cholesterol), SUPD (Statin Use in Persons with Diabetes) |
| **Cadence** | Weekly — runs each Monday (or any day; uses the Monday of the current week as the run identifier) |
| **Consumers** | Regional pharmacy teams, provider groups, and clinical pharmacists who use the output workbooks for outreach |
| **Database** | `RX_PROVIDER_COLLAB` on SQL Server instance `DC04PWVSQL402\sql01, 10001` |

### Key Data Tables

| Table | Purpose |
|-------|---------|
| `STAR_PROVIDER_DATA` | Member-level adherence detail — one row per member per provider/pharmacy relationship. ~170+ columns covering demographics, PDC scores, prescriptions, pharmacy info, med safety, etc. |
| `PEP_PERFORMANCE_WEEKLY` | PGID-level weekly performance aggregates — numerators/denominators for adherence rates, historical trending |

---

## 3. Architecture & Data Flow

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                          PEP Automation Pipeline                            │
├──────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────┐    ┌──────────────┐    ┌───────────────┐                   │
│  │ config.json  │───>│   main.py    │<───│ ReportWorkbook│                   │
│  │ (settings)   │    │  (7200+ LOC) │    │   .xlsb       │                   │
│  └─────────────┘    └──────┬───────┘    │ (group list)  │                   │
│                            │            └───────────────┘                   │
│                            │                                                │
│              ┌─────────────┼──────────────┐                                 │
│              ▼             ▼              ▼                                  │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐                      │
│  │  SQL Server   │  │ Parquet Cache │  │  PEP_Auto.   │                     │
│  │ STAR_PROVIDER │  │ (cache/*.pq)  │  │  xlsb        │                     │
│  │ _DATA         │  │              │  │ (template)   │                      │
│  │ PEP_PERF_     │  └──────────────┘  └──────┬───────┘                     │
│  │ WEEKLY        │                           │                              │
│  └──────────────┘                 ┌──────────┘                              │
│                                   │                                         │
│         FOR EACH ROW in ReportWorkbook:                                     │
│         ┌─────────────────────────┼────────────────────────────┐            │
│         │ 1. Filter data by PGID/TIN/Contract/CA_GROUP          │           │
│         │ 2. Copy template → temp workbook                      │           │
│         │ 3. Write filtered data via Excel COM                  │           │
│         │ 4. Build dashboard, SUPD list, unpivoted report, etc. │           │
│         │ 5. Save as .xlsb → destination/<monday_date>/         │           │
│         └───────────────────────────────────────────────────────┘           │
│                                   │                                         │
│                                   ▼                                         │
│                    ┌─────────────────────────┐                              │
│                    │  temp/complete/<date>/   │      ┌──────────────────┐   │
│                    │  ├── <market_folder>/    │─────>│ Shared Drive     │   │
│                    │  │   └── Group_YYYYMMDD  │      │ (optional move)  │   │
│                    │  │       .xlsb           │      └──────────────────┘   │
│                    │  └── Verification_Report │                              │
│                    └─────────────────────────┘                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

### High-Level Flow (in order)

1. **Load config** from `config.json`
2. **Kill Excel** processes (optional, controlled by `force_kill_excel`)
3. **Create/verify** output folders
4. **Test database** connection
5. **Fetch data** from `STAR_PROVIDER_DATA` (with Parquet caching)
6. **Fetch PGID performance** data from `PEP_PERFORMANCE_WEEKLY` (with Parquet caching)
7. **Read ReportWorkbook** — get list of all provider groups to process
8. **Load checkpoint** — skip previously completed rows if resuming
9. **Process each row** (parallel or sequential):
   - Extract identifiers (PGID, TIN, Contract, CA_GROUP)
   - Filter the master DataFrame
   - Copy the template workbook
   - Write data into the copy (Full Report sheet)
   - Run Excel processing steps (dashboard, tables, charts, SUPD, etc.)
   - Save as `.xlsb` to the dated output folder
10. **Retry** any failed rows (up to N attempts)
11. **Verify** output files and generate verification report
12. **Move** dated folder to shared drive (optional)
13. **Cleanup** COM objects, temp files, and Excel processes

---

## 4. Prerequisites & Environment Setup

### System Requirements

| Requirement | Detail |
|-------------|--------|
| **OS** | Windows (COM automation requires it) |
| **Python** | 3.10+ recommended |
| **Microsoft Excel** | Must be installed locally (COM automation via `win32com`) |
| **SQL Server Access** | Windows Authentication (trusted connection) to `DC04PWVSQL402\sql01` |
| **ODBC Driver** | "SQL Server" ODBC driver must be installed |
| **Network** | Access to the shared drive (if `move_final_folder` is enabled) |

### Python Setup

```bash
# 1. Create a virtual environment (recommended)
python -m venv .venv
.venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt
```

### Dependencies (`requirements.txt`)

| Package | Version | Purpose |
|---------|---------|---------|
| `pandas` | 2.2.3 | Data manipulation and filtering |
| `numpy` | 2.2.1 | Vectorized calculations |
| `pyarrow` | 18.1.0 | Parquet file I/O for caching |
| `sqlalchemy` | 2.0.41 | Database connection engine |
| `pyodbc` | 5.2.0 | ODBC driver for SQL Server |
| `openpyxl` | 3.1.5 | `.xlsx` reading/writing (verification report) |
| `xlsxwriter` | 3.2.0 | Excel writing support |
| `pyxlsb` | 1.0.10 | Reading `.xlsb` files (ReportWorkbook) |
| `psutil` | 6.1.1 | System resource monitoring (CPU, memory) |
| `tqdm` | 4.67.1 | Progress bars in the console |
| `pywin32` | 308 | Excel COM automation (`win32com`, `pythoncom`) |
| `aiofiles` | 24.1.0 | Async file I/O (reserved for future use) |

---

## 5. Directory Structure

```
PEP Automation Optimized WoW - 2026/
│
├── main.py                          # ★ THE ENTIRE APPLICATION (single file, ~7200+ lines)
├── config.json                      # Runtime configuration (paths, flags, parallelism)
├── CONFIG_README.md                 # Configuration field reference
├── requirements.txt                 # Python dependencies
├── HANDOFF_DOCUMENTATION.md         # ← YOU ARE HERE
│
├── templates/
│   ├── PEP_Automation.xlsb          # ★ TEMPLATE workbook — copied per provider group
│   └── ReportWorkbook.xlsb          # ★ INPUT — list of provider groups to process
│
├── cache/
│   ├── db_metadata_cache.json       # Timestamp of last STAR_PROVIDER_DATA fetch
│   ├── pgid_perf_metadata_cache.json # Timestamp of last PEP_PERFORMANCE_WEEKLY fetch
│   ├── star_provider_data.parquet   # Cached STAR_PROVIDER_DATA (generated at runtime)
│   ├── pgid_perf_data.parquet       # Cached PEP_PERFORMANCE_WEEKLY (generated at runtime)
│   └── progress_checkpoint.json     # Resume checkpoint (generated at runtime)
│
├── temp/                            # Working directory for in-progress workbook copies
│   └── complete/                    # Default local output folder
│       └── <YYYYMMDD>/             # Dated subfolder (e.g., 20260302/)
│           ├── <Market>/           # Subfolder per market/region
│           │   └── GroupName_20260302.xlsb
│           └── FINAL_Verification_Report.xlsx
│
├── logs/
│   └── excel_automation_python_db.log  # Application log
│
└── zOLD/                            # Archived previous versions (reference only)
```

### Critical Files

| File | Modify? | Description |
|------|---------|-------------|
| `main.py` | Yes (with care) | All application logic — single-file monolith |
| `config.json` | Yes | All runtime settings — change this, not the code |
| `templates/PEP_Automation.xlsb` | Rarely | The Excel template — must stay in `.xlsb` format |
| `templates/ReportWorkbook.xlsb` | Weekly | The input list — updated each week with current provider groups |

---

## 6. Configuration Reference

All settings live in `config.json`. See [CONFIG_README.md](CONFIG_README.md) for the full field-level reference. Key settings summarized below:

### Most Important Settings

```json
{
  "database_server": "DC04PWVSQL402\\sql01, 10001",
  "database_name": "RX_PROVIDER_COLLAB",
  "parallel_processing_enabled": true,
  "parallel_max_workers": 4,
  "retry_max_attempts": 2,
  "resume_from_checkpoint": true,
  "test_mode": false,
  "max_test_rows": 100,
  "move_final_folder": true,
  "shared_drive_destination": "Z:\\Clinical Pharmacy Strategies\\..."
}
```

### Settings to Know

| Setting | When to Change |
|---------|---------------|
| `test_mode` / `max_test_rows` | Set `true` + small number to test with a few rows |
| `parallel_max_workers` | Reduce if machine has limited RAM; increase on powerful machines |
| `force_kill_excel` | Set `false` if you have other Excel workbooks open |
| `move_final_folder` | Set `false` to keep output local only |
| `resume_from_checkpoint` | Set `false` to force a fresh start (ignores prior partial runs) |

---

## 7. How to Run

### Standard Weekly Run

```bash
# From the project root directory:
python main.py
```

That's it. The script is fully automated and will:
1. Print a progress bar to the console
2. Log details to `logs/excel_automation_python_db.log`
3. Prompt before killing Excel (with a 3-minute timeout, defaults to "Yes")
4. Prompt before overwriting existing output (if a folder for this Monday already exists)
5. Move completed files to the shared drive (if configured)

### Test Run

Edit `config.json`:
```json
{
  "test_mode": true,
  "max_test_rows": 6,
  "move_final_folder": false
}
```
Then run `python main.py`. Only the first 6 data rows will be processed.

### Resuming After a Crash

If the script crashes mid-run, simply re-run `python main.py`. The checkpoint system will:
- Detect the previous partial run
- Verify which output files actually exist on disk
- Skip already-completed rows
- Resume from where it left off

To force a fresh start (ignoring the checkpoint), either:
- Delete `cache/progress_checkpoint.json`, or
- Set `"resume_from_checkpoint": false` in `config.json`

### Debug Mode

Set the `DEBUG_MODE` environment variable for verbose logging:
```bash
set DEBUG_MODE=1
python main.py
```
This creates a separate `logs/excel_automation_debug.log` with function-level detail.

---

## 8. Detailed Processing Pipeline

### Per-Row Processing Steps (what happens for each provider group)

Each row in the ReportWorkbook represents one provider group. For each row, the script:

| Step | Function | What It Does |
|------|----------|-------------|
| 1 | `extract_report_row_data()` | Parses the row: extracts PGIDs, TINs, Contract IDs, CA_GROUPs, group name, market subfolder |
| 2 | `filter_dataframe_smart()` | Filters the master STAR DataFrame to only rows matching this group's identifiers |
| 3 | Pool/SaveCopyAs | Gets a fresh copy of the template workbook (from pool or via `SaveCopyAs`) |
| 4 | `write_data_to_excel_optimized()` | Writes the filtered DataFrame into the "Full Report" sheet |
| 5 | `update_dashboard()` | Sets the group name in the Performance Dashboard |
| 6 | `resize_tables_smart()` | Resizes Excel ListObject tables to match the number of data rows |
| 7 | `CalculateFull()` | Forces Excel to recalculate all formulas |
| 8 | `copy_member_list_values()` | Copies formula results to values in the Member List sheet |
| 9 | `copy_med_safety_values()` | Copies formula results to values in the Med Safety sheet |
| 10 | `remove_blank_med_safety_rows()` | Removes rows with no ACH/COB compliance data |
| 11 | `create_supd_list()` | Creates the SUPD (Statin Use in Persons with Diabetes) sheet |
| 12 | `clear_member_list_filters()` | Removes any active filters from the Member List |
| 13 | `create_unpivoted_report()` | Creates an "Unpivoted Report" sheet — restructures measure-level data for easier analysis |
| 14 | Delete "WoW Performance" | Conditionally removes the WoW sheet if the group is TIN/Contract/CA_GROUP only (no PGID) |
| 15 | `write_pgid_performance_to_excel()` | Writes historical PGID performance trending data |
| 16 | `sort_sheets_in_workbook()` | Alphabetically sorts worksheet tabs |
| 17 | `refresh_chart_axes()` | Refreshes chart axis bounds |
| 18 | `save_final_workbook()` | Saves as `.xlsb` to the destination folder |

### ReportWorkbook Columns

The ReportWorkbook (`.xlsb`) must have a sheet named **"Report"** with these columns:

| Column | Required? | Description |
|--------|-----------|-------------|
| `PGID` | At least one ID type | Comma-separated Provider Group IDs |
| `TIN` | At least one ID type | Comma-separated Tax Identification Numbers |
| `CONTRACT_ID` | At least one ID type | Comma-separated CMS Contract IDs |
| `CA_GROUP` | At least one ID type | Comma-separated CA Group names |
| `Provider Group (REPORT NAME)` | Yes | Display name — used in the output filename and dashboard title |
| `Market (REPORTING FOLDER)` | Yes | Market/region name — used as the subfolder in the output directory |

> **Note:** Each row must have at least one identifier (PGID, TIN, CONTRACT_ID, or CA_GROUP). Rows with no identifiers are skipped.

---

## 9. Database & Data Sources

### Connection

- **Method:** Windows Authentication (trusted connection) via `pyodbc` + `sqlalchemy`
- **Connection string pattern:**
  ```
  mssql+pyodbc://@<server>/<database>?driver=SQL+Server&trusted_connection=yes&timeout=30
  ```
- The user running the script must have `SELECT` permission on both tables.

### Tables

#### `STAR_PROVIDER_DATA`

- **~170+ columns** of member-level pharmacy adherence data
- **Key columns:** `MCID` (member ID), `PGID`, `PROVIDERTIN`, `CONTRACT_ID`, `CA_GROUP`, `CREATEDDATE`
- **Adherence measures:** ACE/ARB, Diabetes, Statin — each with PDC, fill dates, pharmacy info, compliance flags
- **Med safety:** ACH (Antidepressant) and COB (Cardiovascular) columns
- **Full column list:** See `STAR_PROVIDER_BASE_COLUMNS` in `main.py` (~lines 2268-2590)

#### `PEP_PERFORMANCE_WEEKLY`

- **PGID-level aggregate** performance data — numerators and denominators
- **Columns:** `PGID`, `CREATEDDATE`, `SUPD_IND_NUM/DENOM`, `STATN_COMPLIANCE_NUM/DENOM`, `DBTS_COMPLIANCE_NUM/DENOM`, `ACE_ARB_COMPLIANCE_NUM/DENOM`, `PHARMACY_DELIVERY_NUM/DENOM`, `STATN_HD_NUM`, `DBTS_HD_NUM`, `ACE_ARB_HD_NUM`, `STATN_EDS_NUM`, `DBTS_EDS_NUM`, `ACE_ARB_EDS_NUM`
- **Filter:** Only current year and prior year data is fetched (`WHERE YEAR(CREATEDDATE) IN (<prior>, <current>)`)

### Data Type Handling

The `_post_fetch_processor_star_provider()` function applies explicit type conversions after fetch:
- **Integer columns** → `Int64` (nullable integer)
- **Float columns** → `float64`
- **Date columns** → `datetime64` (normalized to midnight)
- **Categorical columns** → `category` (memory optimization)
- **String columns** → `string` dtype

---

## 10. Caching System

The script uses a **two-tier caching** strategy to avoid re-downloading large datasets on every run:

### How It Works

1. **Metadata cache** (`cache/db_metadata_cache.json`):
   - Stores the `MAX(CREATEDDATE)` timestamp from the last successful fetch
   - On each run, the script queries `SELECT MAX(CREATEDDATE) FROM <table>` and compares

2. **Data cache** (`cache/star_provider_data.parquet`):
   - Stores the full DataFrame as a Parquet file (fast, compressed, type-preserving)
   - Only re-downloaded when the database timestamp is newer than the cached timestamp

### Cache Invalidation

The cache is re-fetched when:
- The `MAX(CREATEDDATE)` in the database is newer than the cached timestamp
- The cache files are missing or corrupted
- The Parquet file fails to read (auto-cleanup and re-fetch)

### Manual Cache Clearing

To force a fresh data pull, delete the cache files:
```bash
del cache\star_provider_data.parquet
del cache\db_metadata_cache.json
del cache\pgid_perf_data.parquet
del cache\pgid_perf_metadata_cache.json
```

---

## 11. Parallel Processing

### Overview

When `parallel_processing_enabled` is `true`, the script uses a **ThreadPoolExecutor** with multiple Excel instances to process rows concurrently.

### How It Works

1. `AdaptiveParallelConfig` auto-detects optimal worker count based on:
   - CPU cores (physical and logical)
   - Available system memory
   - VM/container detection (applies 25% reduction for VMs)
   
2. Rows are split into **batches** distributed across workers
3. Each worker thread initializes its own **COM apartment** (`CoInitializeEx` with `COINIT_APARTMENTTHREADED`) and its own **Excel instance** (`DispatchEx`)
4. Progress is tracked at the batch level with `tqdm`

### Why Threads Instead of Processes?

Excel COM objects cannot be pickled across process boundaries. The script uses `ThreadPoolExecutor` with per-thread COM initialization to work around this. Each thread gets an isolated Excel instance via `DispatchEx`.

### Fallback to Sequential

Parallel mode falls back to sequential when:
- `parallel_processing_enabled` is `false`
- Worker count calculates to ≤ 1
- Total rows < 10 (overhead isn't worth it)
- Insufficient memory (< 2 GB free)

### Adaptive Scaling

When `parallel_adaptive_scaling` is `true`, the system dynamically adjusts worker count during processing:
- Reduces workers if available memory drops below 2 GB
- Increases workers (up to max) when memory is abundant

---

## 12. Retry, Resume & Checkpointing

### Retry Logic

After the main processing loop, any failed rows are retried:

1. **Pre-check**: Before retrying, `_pre_check_row_has_data()` checks if the row actually has matching data in the database. Rows with no data are skipped (they'll always "fail").
2. **Fresh Excel**: Each retry round kills Excel, garbage collects, and starts a fresh Excel instance.
3. **Max attempts**: Controlled by `retry_max_attempts` (default: 2).

### Checkpoint / Resume

The checkpoint system enables crash recovery:

1. **Saving**: After each completed row (or batch in parallel mode), the current state is written atomically to `cache/progress_checkpoint.json` (temp file → rename).
2. **Loading**: On the next run, the checkpoint is loaded and verified:
   - Only rows whose output files **actually exist on disk** are considered complete
   - The checkpoint includes a **config hash** — if key config values change, the checkpoint is invalidated
3. **Clearing**: On 100% success, the checkpoint file is deleted.

### Checkpoint File Format

```json
{
  "monday_date": "20260302",
  "config_hash": "a1b2c3d4...",
  "successful_rows": [2, 3, 4, 5],
  "failed_rows": [6],
  "total_rows": [2, 3, 4, 5, 6]
}
```

---

## 13. Output & Delivery

### Output File Naming

```
<destination_folder>/<monday_date>/<market_subfolder>/<GroupName>_<monday_date>.xlsb
```

Example:
```
temp/complete/20260302/California/HealthFirst_Medical_Group_20260302.xlsb
```

### File Format

Output is saved as **`.xlsb`** (Excel Binary Workbook) for:
- Smaller file sizes (~60-70% smaller than `.xlsx`)
- Faster save times via COM
- Compatibility with the template's macros and formatting

### Verification Report

After processing, `verify_files_against_report_excel()` generates `FINAL_Verification_Report.xlsx`:
- Color-coded rows: **Green** = Success, **Red** = Failed, **Yellow** = No Data, **Blue** = Skipped
- Distinguishes between "no matching data" (expected) vs. "processing error" (unexpected failure)

### Shared Drive Move

When `move_final_folder` is `true`:
- The entire dated subfolder is moved (not copied) to `shared_drive_destination`
- If the move fails (e.g., network issue), the user is prompted to retry (with auto-retry default)
- Files remain in the local folder if the move is declined

---

## 14. Excel Template Workbooks

### `PEP_Automation.xlsb` (Template)

This is the **master template** that gets copied for each provider group. It contains:

| Sheet | Purpose |
|-------|---------|
| **Performance Dashboard** | Summary dashboard with charts — group name is set dynamically |
| **Full Report** | Raw member-level data table — populated by the script |
| **Member List** | Filtered/formatted view of the Full Report — formulas are pasted as values |
| **Med Safety** | ACH/COB medication safety data — blank rows removed after calculation |
| **SUPD List** | Statin Use in Persons with Diabetes — built dynamically |
| **Unpivoted Report** | Measure-by-measure restructured data — created dynamically |
| **WoW Performance** | Week-over-week PGID performance trending (deleted if non-PGID group) |

> ⚠️ **CRITICAL**: The template must remain in `.xlsb` format. Do NOT save it as `.xlsx`.  
> ⚠️ **CRITICAL**: If the template structure changes (sheet names, table names, column order), the corresponding code in `main.py` must be updated.

### `ReportWorkbook.xlsb` (Input)

- Contains a single sheet named **"Report"**
- Each row is one provider group to process
- Updated weekly with the current list of groups
- Must have the column headers described in Section 8

---

## 15. Key Functions Reference

### Entry Point & Orchestration

| Function | Line | Purpose |
|----------|------|---------|
| `main()` | ~7181 | Entry point — orchestrates the entire pipeline |
| `process_rows_parallel()` | ~929 | Manages parallel batch processing with ThreadPoolExecutor |
| `process_rows_sequential()` | ~1225 | Sequential row-by-row processing loop |
| `process_row_wrapper()` | ~6437 | Full lifecycle for one row: filter → copy → write → process → save |
| `run_excel_processing_steps()` | ~6158 | All 13+ Excel manipulation steps for one workbook |

### Data Layer

| Function | Line | Purpose |
|----------|------|---------|
| `fetch_all_data_once()` | ~3578 | Fetches STAR_PROVIDER_DATA (with caching) |
| `fetch_pgid_performance_data()` | ~3651 | Fetches PEP_PERFORMANCE_WEEKLY (with caching) |
| `fetch_data_generic()` | ~3067 | Generic cached-fetch engine (used by both above) |
| `filter_dataframe_smart()` | ~3683 | Filters master DataFrame by PGID/TIN/Contract/CA_GROUP |
| `_post_fetch_processor_star_provider()` | ~3396 | Type conversions and column ordering for STAR data |
| `_post_fetch_processor_pep_performance()` | ~3600 | Post-processing for PEP performance data |

### Excel COM Operations

| Function | Line | Purpose |
|----------|------|---------|
| `write_data_to_excel_optimized()` | ~1408 | Writes a DataFrame to an Excel sheet via COM |
| `resize_tables_smart()` | ~4360 | Resizes Excel ListObject tables to fit data |
| `create_supd_list()` | ~4576 | Builds the SUPD worksheet |
| `create_unpivoted_report()` | ~4978 | Creates the unpivoted measure-level report |
| `write_pgid_performance_to_excel()` | ~4371 | Writes PGID performance trending data |
| `copy_member_list_values()` | ~4777 | Pastes formula results as values in Member List |
| `copy_med_safety_values()` | ~4804 | Pastes formula results as values in Med Safety |
| `remove_blank_med_safety_rows()` | ~4831 | Removes rows with no med safety data |
| `sort_sheets_in_workbook()` | ~5965 | Alphabetically sorts worksheet tabs |
| `refresh_chart_axes()` | ~6033 | Refreshes chart axis ranges |
| `save_final_workbook()` | ~6085 | Saves the workbook as `.xlsb` |

### Excel Utilities

| Function | Line | Purpose |
|----------|------|---------|
| `reinitialize_excel()` | ~3789 | Creates a new Excel COM instance |
| `kill_excel_processes()` | ~3758 | Force-kills all `EXCEL.EXE` processes |
| `open_workbook()` | ~3856 | Opens a workbook with retry logic |
| `wait_until_ready()` | ~3894 | Waits for Excel to finish calculating |
| `release_com_object()` | ~3811 | Properly releases a COM object |
| `get_worksheet()` | ~3949 | Gets a worksheet by name (case-insensitive) |
| `get_list_object()` | ~4147 | Gets an Excel ListObject (table) by name |

### Support Functions

| Function | Line | Purpose |
|----------|------|---------|
| `get_monday_date()` | ~3719 | Returns the Monday of the current week as `YYYYMMDD` |
| `sanitize_filename()` | ~3726 | Removes invalid characters from filenames |
| `verify_files_against_report_excel()` | ~7697 | Post-run verification and report generation |
| `move_folder_with_progress()` | ~6959 | Moves output folder to shared drive with progress bar |
| `timed_input()` | ~1944 | Console input with timeout (defaults if no response) |

### Performance & Optimization Classes

| Class | Line | Purpose |
|-------|------|---------|
| `DataFrameFilterOptimizer` | ~151 | Cached index-based DataFrame filtering (~70-90% faster) |
| `MemoryOptimizer` | ~297 | DataFrame memory usage reduction via downcasting |
| `SmartCache` | ~413 | In-memory TTL cache for frequently accessed data |
| `WorkbookPool` | ~471 | Pre-copied template workbook pool (~20-40% less I/O) |
| `AdaptiveParallelConfig` | ~614 | Auto-tuning parallel worker configuration |
| `BatchProcessor` | ~375 | Batch row processing with inter-batch GC |

---

## 16. Error Handling & Recovery

### COM Crash Detection

The script detects Excel COM crashes via specific HRESULT error codes:

| HRESULT | Meaning |
|---------|---------|
| `-2147023174` | RPC server unavailable (Excel process died) |
| `-2147417848` | COM object disconnected |
| `-2147220995` | COM server not connected |
| `-2146959355` | Server execution failed (Excel couldn't launch) |

When a fatal COM error is detected, `ExcelCOMCrashError` is raised, triggering:
1. Full Excel cleanup (kill all processes)
2. COM re-initialization
3. New Excel instance creation
4. Resumption from the next row

### Parallel Worker Recovery

In parallel mode, if a worker's Excel instance crashes:
1. The dead instance is cleaned up
2. Re-initialization is attempted with **increasing delays** (1s, 2s, 4s)
3. If all re-init attempts fail, remaining rows in that batch are marked as failed
4. Failed rows are retried in the post-processing retry phase

### Memory Pressure

- `psutil` monitors available memory
- If memory drops below 2 GB, parallel workers are reduced
- `gc.collect()` is called between batches and after each row cleanup
- DataFrame memory is optimized via downcasting (Int64 → Int32, float64 → float32, strings → categories)

---

## 17. Logging & Diagnostics

### Log Files

| File | Level | Content |
|------|-------|---------|
| `logs/excel_automation_python_db.log` | INFO+ | Main application log — timestamped, append-mode |
| `logs/excel_automation_debug.log` | DEBUG+ | Verbose debug log (only when `DEBUG_MODE=1`) |
| Console (stdout) | WARNING+ | Minimal console output (warnings and errors only) |

### Log Format

```
2026-03-02 08:30:15,123 - INFO - Successfully read 250 rows from report workbook.
```

### COM Warning Filter

A custom `COMWarningFilter` suppresses noisy COM-related messages (e.g., "CoInitialize has not been called") and truncates overly long messages to 100 characters.

### What to Look For

- `CRITICAL` — Script-ending errors (database failure, Excel can't initialize)
- `ERROR` — Row-level failures (will be retried)
- `WARNING` — Non-fatal issues (missing sheet, failed to set a property)
- `INFO` — Normal progress milestones

---

## 18. Performance Optimizations

The script includes several numbered optimizations:

| # | Optimization | Impact | Implementation |
|---|-------------|--------|----------------|
| 4 | **Workbook Pool** | 20-40% less file I/O | Pre-copies N templates at startup; workers reuse copies |
| 5 | **Parallel Processing** | 2-4x throughput | ThreadPoolExecutor + per-thread Excel instances |
| 6 | **Indexed Filtering** | 70-90% faster filtering | `DataFrameFilterOptimizer` pre-builds groupby indices |
| 7 | **Memory Optimization** | 30-60% less RAM | Downcasting numerics, categoricals, string dtypes |
| 10 | **`__slots__`** | Minor memory savings | Used on all optimization classes |
| 11 | **Pre-compiled Regex** | Minor CPU savings | Module-level compiled patterns |
| 13 | **Frozen Constants** | Minor lookup savings | `frozenset` for column name lookups |
| — | **Chunked Range Write** | Prevents COM timeouts | Writes to Excel in 500-row chunks |
| — | **Parquet Caching** | Minutes saved per run | Avoids re-downloading 100K+ rows each time |
| — | **Vectorized Helpers** | ~10x faster than loops | NumPy vectorized column calculations |

---

## 19. Troubleshooting Guide

### Common Issues

#### "Database connection test failed"

- **Cause:** Can't reach SQL Server or no Windows Auth permission
- **Fix:** Verify network connectivity, VPN status, and database permissions. Test with SSMS.

#### "Template file not found"

- **Cause:** `PEP_Automation.xlsb` is missing from `templates/`
- **Fix:** Restore the template file. Must be `.xlsb` format.

#### Rows failing with COM errors

- **Cause:** Excel process crashed or became unresponsive
- **Fix:** Usually auto-recovered via retry logic. If persistent:
  - Reduce `parallel_max_workers` to 2 or 1
  - Set `parallel_processing_enabled: false` to use sequential mode
  - Ensure machine has sufficient RAM (at least 2 GB free + 0.5 GB per worker)

#### "Checkpoint found but no rows could be verified"

- **Cause:** Output files from the previous run were deleted/moved, but the checkpoint file remains
- **Fix:** Delete `cache/progress_checkpoint.json` to start fresh

#### Output files have wrong data or empty sheets

- **Cause:** Template workbook structure has changed (sheet names, table names)
- **Fix:** Compare the template against the expected sheet/table names in the code (Section 14)

#### Move to shared drive fails

- **Cause:** Network drive is disconnected or permissions issue
- **Fix:** The script will prompt to retry. Reconnect to VPN/network and retry. Files remain in local `temp/complete/` if move fails.

#### Script runs out of memory

- **Cause:** Too many parallel workers + large dataset
- **Fix:**
  - Reduce `parallel_max_workers` (e.g., to 2)
  - Set `parallel_memory_per_worker_gb` higher (e.g., 1.0)
  - Close other applications

#### Verification report shows "No Data" for many rows

- **Cause:** The database doesn't have data for those PGIDs/TINs — this is **expected**, not an error
- **Fix:** No action needed. These rows are correctly identified as "No Data" (yellow).

### Nuclear Reset

If everything is broken and you need a clean slate:

```bash
# 1. Kill all Excel instances
taskkill /F /IM EXCEL.EXE

# 2. Clear all caches and checkpoints
del cache\*.parquet
del cache\*.json

# 3. Clear temp files
rmdir /S /Q temp

# 4. Run fresh
python main.py
```

---

## 20. Maintenance & Year-over-Year Changes

### What Changes Each Year

1. **Update the project folder name** (e.g., "2027" instead of "2026")
2. **Update `shared_drive_destination`** in `config.json` to the new year's folder
3. **Verify database columns** — if `STAR_PROVIDER_DATA` or `PEP_PERFORMANCE_WEEKLY` columns are added/removed:
   - Update `STAR_PROVIDER_BASE_COLUMNS` in `main.py` (~line 2268)
   - Update `PEP_PERFORMANCE_BASE_COLUMNS` in `main.py` (~line 2586)
   - Update type conversion lists in `_post_fetch_processor_star_provider()`
4. **Update the template** (`PEP_Automation.xlsb`) if the dashboard layout changes
5. **Clear all caches** at the start of the new year

### What Changes Each Week

1. **Update `ReportWorkbook.xlsb`** with the current week's provider group list
2. **Run `python main.py`** — caching will auto-detect if data has changed

### Adding a New Column

If a new column is added to the database:

1. Add it to `STAR_PROVIDER_BASE_COLUMNS` (or `PEP_PERFORMANCE_BASE_COLUMNS`)
2. Add it to the appropriate type conversion set in the post-fetch processor:
   - `int_columns`, `float_columns`, `datetime_columns`, `categorical_columns`, or `string_columns`
3. If it needs special display handling, add it to `NULLABLE_COLUMNS` or `DATE_COLUMNS`
4. Update the template workbook if the column needs to appear in a sheet
5. Clear the Parquet cache (`del cache\star_provider_data.parquet`)

---

## 21. Known Limitations & Risks

| Limitation | Impact | Mitigation |
|-----------|--------|-----------|
| **Windows-only** | Cannot run on Linux/Mac | Excel COM requires Windows + Excel installed |
| **Single-file monolith** | 7200+ lines in one file | Well-organized with section headers; consider modularizing if major changes are needed |
| **Excel COM instability** | COM crashes are possible, especially under parallel load | Retry logic + checkpoint/resume handles most cases |
| **Memory usage** | Large datasets + multiple Excel instances consume significant RAM | Adaptive scaling, memory monitoring, downcasting |
| **Network dependency** | Shared drive move requires network connectivity | Retry prompts; files preserved locally if move fails |
| **Template coupling** | Code is tightly coupled to template sheet/table names | Any template change requires code updates |
| **No unit tests in production** | `pytest` is in requirements but no test suite exists | Consider adding tests for critical functions |
| **Trusted connection only** | Uses Windows Auth — no SQL username/password support | Must run under an account with DB read access |

---

## 22. Glossary

| Term | Definition |
|------|-----------|
| **PEP** | Pharmacy Engagement Program — CMS STAR rating improvement initiative |
| **STAR** | CMS 5-Star Quality Rating System for Medicare Advantage plans |
| **PDC** | Proportion of Days Covered — key adherence metric (0-100%) |
| **PGID** | Provider Group ID — unique identifier for a provider group |
| **TIN** | Tax Identification Number — identifies a provider entity |
| **SUPD** | Statin Use in Persons with Diabetes — STAR quality measure |
| **ACE/ARB** | ACE Inhibitors / Angiotensin Receptor Blockers — hypertension measure |
| **DBTS** | Diabetes medications adherence measure |
| **STATN** | Statin (cholesterol) medications adherence measure |
| **ACH** | Antidepressant medication management |
| **COB** | Cardiovascular (cholesterol/blood pressure) medication management |
| **COM** | Component Object Model — Windows technology for Excel automation |
| **WoW** | Week-over-Week — performance trending comparison |
| **MCID** | Member CMS ID — unique patient identifier |
| **ReportWorkbook** | The input Excel file listing all provider groups to process |
| **Monday date** | The Monday of the current week, used as the run identifier (`YYYYMMDD`) |
| **Parquet** | Columnar file format used for caching DataFrames (fast, compressed) |

---

## Quick-Start Checklist for New Team

- [ ] Windows machine with Python 3.10+ and Microsoft Excel 64-bit installed (**Must be 64-bit Excel**)
- [ ] Clone/copy the project folder
- [ ] Create virtual environment and `pip install -r requirements.txt`
- [ ] Verify SQL Server access (try connecting via SSMS to `DC04PWVSQL402\sql01, 10001`)
- [ ] Verify shared drive access (if using `move_final_folder`)
- [ ] Review `config.json` — update `shared_drive_destination` if needed
- [ ] Do a test run: set `test_mode: true`, `max_test_rows: 3`, `move_final_folder: false`
- [ ] Run `python main.py` and verify output in `temp/complete/<date>/`
- [ ] Check `logs/excel_automation_python_db.log` for any issues
- [ ] Review the `FINAL_Verification_Report.xlsx` in the output folder
- [ ] Once satisfied, set `test_mode: false` and run the full batch
