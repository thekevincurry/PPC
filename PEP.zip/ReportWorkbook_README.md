# ReportWorkbook Format Check & Row Count

**Script:** `ReportWorkbook_format_check_and_row_count.py`

A standalone validation tool that reads a PEP ReportWorkbook (`.xlsb`), validates and cleans provider data (PGIDs, TINs, Contract IDs, CA_GROUPs), and optionally verifies each row against the `STAR_PROVIDER_DATA` database table. All output is saved as `.xlsb`.

---

## Table of Contents

1. [Overview](#overview)
2. [Prerequisites](#prerequisites)
3. [Configuration](#configuration)
4. [Usage](#usage)
5. [Processing Pipeline](#processing-pipeline)
6. [Data Fixes Applied](#data-fixes-applied)
7. [Validation Rules](#validation-rules)
8. [Database Verification](#database-verification)
9. [Output Files](#output-files)
10. [Output File Structure](#output-file-structure)
11. [Script Constants](#script-constants)
12. [Troubleshooting](#troubleshooting)

---

## Overview

This script performs two main functions:

1. **Format Validation & Cleaning** — Reads the `Report` sheet of a ReportWorkbook, fixes common formatting issues (bad separators, missing leading zeros on TINs), validates each field against expected patterns, and writes a cleaned output with a validation summary.

2. **Database Record Count Verification** — Queries `RX_PROVIDER_COLLAB.dbo.STAR_PROVIDER_DATA` using each row's PGID, TIN, Contract ID, and CA_GROUP values. Appends columns with combined and individual field record counts for comparison.

---

## Prerequisites

| Requirement | Details |
|---|---|
| **Python** | 3.10+ |
| **OS** | Windows (requires Excel COM automation via `win32com`) |
| **Microsoft Excel** | Must be installed locally (used for `.xlsb` conversion) |
| **Database Access** | Windows-authenticated access to SQL Server (`RX_PROVIDER_COLLAB`) |
| **Python Packages** | See `requirements.txt` — key dependencies below |

### Key Python Dependencies

| Package | Purpose |
|---|---|
| `pandas` | DataFrame operations, reading/writing Excel |
| `pyxlsb` | Reading `.xlsb` (Excel Binary Workbook) files |
| `xlsxwriter` | Writing formatted `.xlsx` intermediate files |
| `openpyxl` | Post-processing Excel files (text formatting, cell manipulation) |
| `pywin32` (`win32com`) | COM automation to convert `.xlsx` → `.xlsb` |
| `pyodbc` | SQL Server database connectivity |

Install all dependencies:
```bash
pip install -r requirements.txt
```

---

## Configuration

The script reads from `config.json` in the project root. Relevant keys:

| Key | Type | Description |
|---|---|---|
| `db_server` | string | SQL Server instance (default: `DC04PWVSQL402\sql01, 10001`) |
| `db_name` | string | Database name (default: `RX_PROVIDER_COLLAB`) |
| `report_workbook_path` | string | Path to input ReportWorkbook (overridden by `--report` CLI arg) |

### Script-Level Constants

At the top of the script, two constants control behavior:

| Constant | Default | Description |
|---|---|---|
| `PERFORM_DATABASE_VERIFICATION` | `True` | Set to `False` to skip the database verification step entirely |
| `DEFAULT_REPORT_WORKBOOK_PATH` | `templates/ReportWorkbook.xlsb` | Fallback path if no report path is provided via CLI or config |

---

## Usage

### Full Pipeline (Format Validation + Database Verification)
```bash
python ReportWorkbook_format_check_and_row_count.py --report "path/to/ReportWorkbook.xlsb"
```

### Format Validation Only (No Database)
```bash
python ReportWorkbook_format_check_and_row_count.py --report "path/to/ReportWorkbook.xlsb" --format-only
```

### Using a Custom Config File
```bash
python ReportWorkbook_format_check_and_row_count.py --config "path/to/config.json" --report "path/to/ReportWorkbook.xlsb"
```

### CLI Arguments

| Argument | Required | Description |
|---|---|---|
| `--report` | No | Path to the input ReportWorkbook. Falls back to config or default template path. |
| `--config` | No | Path to config JSON file (default: `config.json`) |
| `--format-only` | No | Flag to skip database verification and only perform format validation |

---

## Processing Pipeline

```
┌─────────────────────────────────────────┐
│  1. READ INPUT (.xlsb)                  │
│     - Uses pyxlsb engine via pandas     │
│     - Reads "Report" sheet              │
└──────────────┬──────────────────────────┘
               │
┌──────────────▼──────────────────────────┐
│  2. FIX & VALIDATE                      │
│     - Fix separators (;|/\ etc → comma) │
│     - Pad TINs to 9 digits (leading 0s) │
│     - Validate PGID, TIN, Contract,     │
│       CA_GROUP formats                  │
└──────────────┬──────────────────────────┘
               │
┌──────────────▼──────────────────────────┐
│  3. WRITE INTERMEDIATE (.xlsx)          │
│     - Cleaned Report sheet              │
│     - Validation Results sheet          │
│     - Summary sheet with chart          │
│     - TIN column formatted as text      │
└──────────────┬──────────────────────────┘
               │
               │  (if --format-only, skip to step 6)
               │
┌──────────────▼──────────────────────────┐
│  4. DATABASE VERIFICATION               │
│     - Combined query (all fields OR'd)  │
│     - Individual field counts            │
│     - Appends 5 new columns to Report   │
│     - Creates DB Summary sheet          │
└──────────────┬──────────────────────────┘
               │
┌──────────────▼──────────────────────────┐
│  5. FINAL CONSOLIDATED REPORT           │
│     - Merges format + DB results        │
│     - Adds Final Summary sheet          │
│     - Calculates pass/fail assessment   │
└──────────────┬──────────────────────────┘
               │
┌──────────────▼──────────────────────────┐
│  6. CONVERT TO .xlsb                    │
│     - Opens .xlsx via Excel COM         │
│     - SaveAs FileFormat=50 (xlExcel12)  │
│     - Deletes intermediate .xlsx        │
└─────────────────────────────────────────┘
```

---

## Data Fixes Applied

### Separator Fixing
Applies to **all four fields** (PGID, TIN, Contract ID, CA_GROUP). Common incorrect separators are replaced with commas:

| Separator | Example |
|---|---|
| `;` | `TIN1;TIN2` → `TIN1,TIN2` |
| `\|` | `TIN1\|TIN2` → `TIN1,TIN2` |
| `/` | `TIN1/TIN2` → `TIN1,TIN2` |
| `\` | `TIN1\TIN2` → `TIN1,TIN2` |
| `-` | `TIN1-TIN2` → `TIN1,TIN2` |
| `_` | `TIN1_TIN2` → `TIN1,TIN2` |
| ` and ` | `TIN1 and TIN2` → `TIN1,TIN2` |
| ` or ` | `TIN1 or TIN2` → `TIN1,TIN2` |
| tab / newline | Various → comma |

Multiple consecutive commas and surrounding whitespace are cleaned up.

### TIN Leading Zero Padding
Every TIN is padded to **9 digits** with leading zeros. Works for single values and comma-separated lists:

| Input | Output |
|---|---|
| `12345` | `000012345` |
| `12345,678901` | `000012345,000678901` |
| `123456789` | `123456789` (unchanged) |

### TIN Text Formatting
TIN values are stored as text (with a leading apostrophe `'`) to prevent Excel from stripping leading zeros.

---

## Validation Rules

| Field | Rule | Pattern | Example |
|---|---|---|---|
| **PGID** | 2 alpha characters + 6 digits | `^[A-Za-z]{2}\d{6}$` | `CA000078` |
| **TIN** | Exactly 9 digits | `^\d{9}$` | `123456789` |
| **Contract ID** | Alphanumeric + hyphens, min 3 chars | `^[A-Za-z0-9\-]{3,}$` | `H0544` |
| **CA_GROUP** | Alphanumeric + underscores/hyphens, min 2 chars | `^[A-Za-z0-9_\-]{2,}$` | `CA_PSFT` |

A row is considered **Valid** if it has at least one valid value in any of the four fields. Rows with all empty fields are marked as **Empty Row**.

---

## Database Verification

When enabled, the script queries `RX_PROVIDER_COLLAB.dbo.STAR_PROVIDER_DATA` for each row.

### Combined Query
All non-empty fields are combined with `OR` logic:
```sql
SELECT COUNT(*) AS RecordCount
FROM RX_PROVIDER_COLLAB.dbo.STAR_PROVIDER_DATA
WHERE PGID IN (?) OR PROVIDERTIN IN (?) OR CONTRACT_ID IN (?) OR CA_GROUP IN (?)
```

### Individual Field Queries
Regardless of the combined result, individual queries are always run for each populated field:

| Column Added | Query |
|---|---|
| **DB Record Count** | Combined query (all fields OR'd) |
| **PGID Only Count** | `WHERE PGID IN (...)` |
| **TIN Only Count** | `WHERE PROVIDERTIN IN (...)` |
| **CONTRACT_ID Only Count** | `WHERE CONTRACT_ID IN (...)` |
| **CA_GROUP Only Count** | `WHERE CA_GROUP IN (...)` |

If the combined count returns 0 and TINs are present, a `LIKE` search is also attempted for fuzzy TIN matching (logged only, not written to output).

---

## Output Files

All output files are saved in the **same directory** as the input file. Intermediate `.xlsx` files are automatically deleted after conversion to `.xlsb`.

| File | When Created | Description |
|---|---|---|
| `{name}_validated_{timestamp}.xlsb` | Always | Cleaned data + validation results |
| `{name}_validated_{timestamp}_db_check_{timestamp}.xlsb` | With DB verification | Adds record count columns |
| `{name}_validated_{timestamp}_db_check_{timestamp}_final_{timestamp}.xlsb` | Full pipeline | Adds Final Summary sheet |

---

## Output File Structure

### Report Sheet
The original report data with fixes applied (separators corrected, TINs padded). Invalid rows are highlighted in red. When database verification is enabled, 5 additional columns are appended.

### Validation Results Sheet
One row per input row with columns:

| Column | Description |
|---|---|
| Row | Excel row number |
| PGID Valid | Yes / No / N/A |
| PGID Error | Description of invalid PGIDs |
| Valid PGID Count | Number of valid PGIDs in cell |
| TIN Valid | Yes / No / N/A |
| TIN Error | Description of invalid TINs |
| Valid TIN Count | Number of valid TINs in cell |
| CONTRACT_ID Valid | Yes / No / N/A |
| CONTRACT_ID Error | Description of invalid Contract IDs |
| Valid CONTRACT_ID Count | Number of valid Contract IDs in cell |
| CA_GROUP Valid | Yes / No / N/A |
| CA_GROUP Error | Description of invalid CA_GROUPs |
| Valid CA_GROUP Count | Number of valid CA_GROUPs in cell |
| Separators Fixed | Yes / No |
| TIN Formatted as Text | Yes / No |
| Overall Status | Valid / Invalid / Empty Row |

Invalid rows are conditionally highlighted in red.

### Summary Sheet
Aggregate statistics with a bar chart:
- Total / Valid / Invalid / Empty Rows
- Rows with Invalid PGIDs / TINs / Contract IDs / CA_GROUPs
- Rows with Separators Fixed / TIN Formatted as Text

### DB Summary Sheet (with database verification)
- Rows with zero / non-zero records
- Rows with errors
- Total database records
- Rows where each individual field query returned results

### Final Summary Sheet (full pipeline)
Consolidated view combining format validation and database verification results:
- Format validation statistics
- Database verification statistics
- Percentage of valid format rows
- Percentage of rows with database records
- Overall status: **PASSED** / **WARNING** / **FAILED**

---

## Script Constants

| Constant | Value | Description |
|---|---|---|
| `PERFORM_DATABASE_VERIFICATION` | `True` | Toggle database verification on/off |
| `xlExcel12` | `50` | Excel COM file format code for `.xlsb` |
| `BASE_DIR` | Script directory | Used for resolving relative paths |
| `DEFAULT_REPORT_WORKBOOK_PATH` | `templates/ReportWorkbook.xlsb` | Default input file |

---

## Troubleshooting

### Common Issues

| Issue | Cause | Solution |
|---|---|---|
| `Error loading config` | Missing or malformed `config.json` | Ensure `config.json` exists in the project root with valid JSON |
| `Report sheet is empty` | No data on the `Report` sheet | Verify the input workbook has data on a sheet named exactly `Report` |
| `Report sheet not found` | Sheet name mismatch | Ensure the workbook contains a sheet named `Report` |
| `Error connecting to database` | Network/auth issues | Verify Windows authentication and VPN/network access to SQL Server |
| `Error converting to xlsb` | Excel not installed or COM error | Ensure Microsoft Excel is installed; close any open Excel instances |
| TINs showing as numbers | Excel stripping leading zeros | The script handles this automatically with text formatting and apostrophe prefixing |

### Logs
All activity is logged to:
- **Console** (stdout)
- **File**: `logs/provider_data_validation.log`

Log entries include timestamps, query details, record counts per row, and error traces for debugging.

### Programmatic Usage

The script can also be imported and used programmatically:

```python
from ReportWorkbook_format_check_and_row_count import ProviderDataValidator

validator = ProviderDataValidator(config_path='config.json')

# Format validation only
results = validator.verify_and_clean_report("path/to/ReportWorkbook.xlsb")
xlsb_path = validator._convert_xlsx_to_xlsb(results['output_path'])

# Full pipeline
results = validator.process_report("path/to/ReportWorkbook.xlsb")
```

### Expected Input Layout

The `Report` sheet should have the following column order:

| Column | A | B | C | D |
|---|---|---|---|---|
| **Header** | PGID | TIN | CONTRACT_ID | CA_GROUP |
| **Example** | CA000078 | 123456789 | H0544 | CA_PSFT |

- Cells may contain multiple comma-separated values
- Additional columns beyond the first four are preserved but not validated
- During database verification, columns 6 and 7 (1-indexed) are read for Contract ID and CA_GROUP respectively
