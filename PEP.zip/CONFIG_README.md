# PEP Automation — Configuration Guide

All settings are defined in `config.json` in the project root. Below is a complete reference of every available option.

---

## Database

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `database_server` | string | `"DC04PWVSQL402\\sql01, 10001"` | SQL Server instance (server\instance, port). |
| `database_name` | string | `"RX_PROVIDER_COLLAB"` | Database name for STAR provider and PGID performance data. |

---

## File Paths

All paths are **optional**. If omitted, they default to locations relative to the script directory.

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `macro_workbook_path` | string | `templates/PEP_Automation.xlsb` | Path to the PEP Automation template workbook. Each row gets a copy of this file. |
| `report_workbook_path` | string | `templates/ReportWorkbook.xlsb` | Path to the Report Workbook containing the list of groups/rows to process. |
| `temp_folder_path` | string | `temp/` | Scratch folder for in-progress workbook copies. Emptied at the start of each run. |
| `destination_folder` | string | `temp/complete/` | Local output folder. Completed `.xlsb` files are saved here under a `<monday_date>/` subfolder. |

---

## Test Mode

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `test_mode` | bool | `false` | When `true`, limits processing to a small number of rows for quick testing. |
| `max_test_rows` | int | `6` | Number of report rows to process when `test_mode` is enabled. Row count starts from the first data row (Excel row 2). |

---

## Processing

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `force_kill_excel` | bool | `true` | Kill all running Excel processes before starting and during cleanup. Set to `false` if you have other Excel workbooks open you want to keep. |
| `workbook_pool_size` | int | `5` | Number of pre-copied template workbooks to keep in the pool for faster row processing (sequential mode only). |

---

## Parallel Processing

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `parallel_processing_enabled` | bool | `true` | Enable multi-threaded row processing. Each worker gets its own Excel instance. Falls back to sequential if the workload is too small. |
| `parallel_max_workers` | int | *auto* | Maximum number of parallel Excel workers. If omitted, calculated automatically based on CPU cores and available memory. |
| `parallel_min_workers` | int | `1` | Minimum number of parallel workers. |
| `parallel_memory_per_worker_gb` | float | `0.5` | Estimated memory (GB) each Excel worker requires. Used to cap worker count to avoid memory pressure. |
| `parallel_adaptive_scaling` | bool | `true` | Dynamically adjust worker count up/down based on real-time memory availability during processing. |

---

## Retry & Resume

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `retry_max_attempts` | int | `2` | Number of retry rounds for rows that failed during the main processing loop. Each attempt uses a fresh Excel instance. Rows with no matching data in the database are automatically skipped (not retried). |
| `resume_from_checkpoint` | bool | `true` | If the script crashes mid-run, the next execution will automatically resume from where it left off. The checkpoint is saved to `cache/progress_checkpoint.json` after every completed row. On resume, each previously-completed row is verified by checking that its output file exists on disk. Set to `false` to always start fresh. |

---

## Output & Delivery

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `move_final_folder` | bool | `false` | After processing, move the dated output folder from the local `destination_folder` to the shared drive. |
| `shared_drive_destination` | string | *(none)* | UNC or mapped-drive path for the shared drive target. Only used when `move_final_folder` is `true`. The dated subfolder (e.g. `20260202`) is appended automatically. |
| `run_final_verification` | bool | `true` | After all processing and retries, generate a verification report (`FINAL_Verification_Report.xlsx`) comparing expected output files against what was actually produced. |

---

## Example `config.json`

```json
{
    "database_server": "DC04PWVSQL402\\sql01, 10001",
    "database_name": "RX_PROVIDER_COLLAB",
    "parallel_processing_enabled": true,
    "parallel_max_workers": 4,
    "parallel_min_workers": 1,
    "parallel_memory_per_worker_gb": 0.5,
    "parallel_adaptive_scaling": true,
    "retry_max_attempts": 2,
    "resume_from_checkpoint": true,
    "test_mode": false,
    "max_test_rows": 15,
    "move_final_folder": true,
    "shared_drive_destination": "Z:\\Clinical Pharmacy Strategies\\Pharmacy Provider Collaboration\\PEP Automation\\2026 PEP"
}
```

---

## Notes

- **Monday date** — The script automatically calculates the Monday of the current week and uses it as the run identifier (`YYYYMMDD` format). All output goes into a subfolder named with this date.
- **Caching** — Database query results are cached locally as Parquet files in the `cache/` folder. On subsequent runs, the script compares the `MAX(CREATEDDATE)` timestamp from the database against the cached value and only re-downloads if the data has changed.
- **Checkpoint safety** — The checkpoint file is written atomically (temp file → rename) so it won't be corrupted even if the script crashes mid-save. The checkpoint is also invalidated if key config values change between runs (paths, test mode, etc.).
